<div class="footer">
            
            <div>
                <strong>Copyright &copy;</strong> Online Art Gallery
            </div>
        </div>